import java.util.ArrayList;

public class AppointmentService {
    
    public static ArrayList<Appointment> appointments = new ArrayList<Appointment>();;

    public AppointmentService(){}

    public void addAppointment( Appointment appointment ){
        //check for duplicate appointment
        for (Appointment a : AppointmentService.appointments) {
            if(a.id.equals(appointment.id))
                throw new IllegalArgumentException(String.format("Id:%s already exists", appointment.id));
        }
        appointments.add(appointment);
    }

    public void deleteAppointment( String id ){

        for (Appointment appointment : appointments) {
            if(appointment.id.equals(id)){
                appointments.remove(appointment);
                System.out.println("Successfully removed appointment(" + id + ")");
                return;
            }
        }
        System.out.println("Unsuccessful appointment id:"+id+" does not exist.");
    }

}
