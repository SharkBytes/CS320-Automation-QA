
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentServiceTest {

    public Appointment validAppointment;
    public AppointmentService service;

    @BeforeEach
    void base(){
        // Clear static state
        AppointmentService.appointments.clear();
        validAppointment = new Appointment("45123", new Date(1750260400000L), "this is something desc");
        service = new AppointmentService();
        // add new appointment
        service.addAppointment(validAppointment);
    }

    @Test
    void addAppointmentFailure(){
        assertThrows(IllegalArgumentException.class, ()->{
            //try to create the same appointment.
            service.addAppointment(new Appointment("45123", new Date(1750260400000L), "this is something desc"));
        });        
    }

    @Test
    void addAppointmentSuccess() {
        //Check if the new appointment exists in the appoints arraylist
        for (Appointment a : AppointmentService.appointments) {
            assertEquals(validAppointment, a);
        }
        
    }

    @Test
    void testDeleteAppointmentSuccess() {

        //old size
        int oldSize = AppointmentService.appointments.size();
        //delete operation
        service.deleteAppointment(validAppointment.id);

        assertFalse(AppointmentService.appointments.contains(validAppointment));
        assertTrue(AppointmentService.appointments.size() < oldSize);

    }

    @Test
    void testDeleteAppointmentFailure() {
        // old size
        int oldSize = AppointmentService.appointments.size();
        
        // delete operation
        service.deleteAppointment("fji234");

        //Same remain same if the appointment does not exist.
        assertTrue(oldSize == AppointmentService.appointments.size());


    }
}
