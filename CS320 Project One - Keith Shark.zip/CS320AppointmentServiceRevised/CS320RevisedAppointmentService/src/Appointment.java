
import java.util.Date;

public class Appointment{

    public final String id;
    private Date date;
    private String description;

    public Appointment(String id, Date date, String description){
        if(date.before(new Date()))
            date.setTime(date.getTime()*1000);
        boolean isNullLengthAndEmptiness = id == null || id.length() > 10 || id.length() == 0 || id.contains(" ");
        boolean isValidDate = date == null || date.before(new Date());
        boolean isValidDescription = description == null || description.length() > 50;
        if( isNullLengthAndEmptiness )
            throw new IllegalArgumentException("id cannot be longer than 10 characters, empty, or null.");
        this.id = id;
        if(isValidDate)
            throw new IllegalArgumentException("Date cannot be in the past and cannot be null. Make sure that date is provided in milliseconds");
        this.date = date;
        if(isValidDescription)
            throw new IllegalArgumentException("description cannot be more than 50 characters and cannot be null.");
        this.description = description;
    }


   
}