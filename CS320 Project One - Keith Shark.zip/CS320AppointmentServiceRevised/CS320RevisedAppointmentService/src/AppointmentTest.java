
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentTest {

    // helper functions
    private boolean isvalidId(String id){
        boolean isNullLengthAndEmptiness = id == null || id.length() > 10 || id.length() == 0 || id.contains(" ");
        return isNullLengthAndEmptiness;
    }
    private boolean isvalidDate(Date date){
        boolean isValidDate = date == null || date.before(new Date());
        return isValidDate;
    }
    private boolean isvalidDescription(String description){
        boolean isValidDescription = description == null || description.length() > 50;
        return isValidDescription;
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"3453234sfe23", "    "})
    void inValidSetId(String input){
        assertTrue(isvalidId(input));
        assertThrows(IllegalArgumentException.class, ()->{
            Appointment createAppointment = new Appointment(input,  new Date(1750475808000L), "this is a valid description");
        });
    }

    @ParameterizedTest
    @ValueSource(strings = { "34fer2", "23fd"})
    void validSetId(String input) {
        assertFalse(isvalidId(input));
    }

    @Test
    void inValidSetDate() {

        assertThrows(NullPointerException.class, ()-> {
            Appointment newAppointment_nullDate = new Appointment("234235", null,"This is a appointment with a null date");
        });
        assertThrows(IllegalArgumentException.class, ()->{
            Appointment newAppointment_pastDate = new Appointment("234235", new Date(1117584000L), "Using a pass date");
        });
    }

    @Test
    void validSetDate() {
        assertFalse(isvalidDate(new Date(1750475808000L)));
    }
    
    @ParameterizedTest
    @NullSource
    @ValueSource(strings = { "this is an invalid description containing more than 50 characters" })
    void inValidDescription(String input) {
        assertTrue(isvalidDescription(input));
        assertThrows(IllegalArgumentException.class, ()->{
            Appointment invalidDescriptioAppointment = new Appointment("1234",  new Date(1750250000L), input);
        });
    }

    @ParameterizedTest
    @ValueSource(strings = { "Appt. for John Doe", "contents Valid" })
    void validDescription(String input) {
        assertFalse(isvalidDescription(input));
    }


}
