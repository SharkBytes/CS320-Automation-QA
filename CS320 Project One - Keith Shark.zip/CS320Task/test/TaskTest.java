import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskTest {

    private String validId;
    private String validName;
    private String validDescription;

    @BeforeEach
    void setUp() {
        validId = "T123456789";
        validName = "Test Task";
        validDescription = "This is a test task description";
    }

    @Test
    void testTaskConstructorWithValidData() {
        Task task = new Task(validId, validName, validDescription);
        assertEquals(validId, task.ID);
        assertEquals(validName, task.getName());
        assertEquals(validDescription, task.getDescription());
    }

    @Test
    void testTaskConstructorWithNullId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, validName, validDescription);
        });
        assertTrue(exception.getMessage().contains("id cannot be null"));
    }

    @Test
    void testTaskConstructorWithLongId() {
        String longId = "12345678901"; // 11 characters
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task(longId, validName, validDescription);
        });
        assertTrue(exception.getMessage().contains("id cannot be null and must be no more than 10 characters"));
    }

    @Test
    void testSetNameWithValidName() {
        Task task = new Task(validId, validName, validDescription);
        String newName = "New Task Name";
        task.setName(newName);
        assertEquals(newName, task.getName());
    }

    @Test
    void testSetNameWithNullName() {
        Task task = new Task(validId, validName, validDescription);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertTrue(exception.getMessage().contains("name cannot be null"));
    }

    @Test
    void testSetNameWithLongName() {
        Task task = new Task(validId, validName, validDescription);
        String longName = "This is a very long name that exceeds the twenty character limit"; // More than 20 characters
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName(longName);
        });
        assertTrue(exception.getMessage().contains("name cannot be null and must be no more than 20 characters"));
    }

    @Test
    void testSetDescriptionWithValidDescription() {
        Task task = new Task(validId, validName, validDescription);
        String newDescription = "New test description";
        task.setDescription(newDescription);
        assertEquals(newDescription, task.getDescription());
    }

    @Test
    void testSetDescriptionWithNullDescription() {
        Task task = new Task(validId, validName, validDescription);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertTrue(exception.getMessage().contains("description cannot be null"));
    }

    @Test
    void testSetDescriptionWithLongDescription() {
        Task task = new Task(validId, validName, validDescription);
        String longDescription = "This is an extremely long description that exceeds the fifty character limit set by the requirements for the Task class description field";
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(longDescription);
        });
        assertTrue(
                exception.getMessage().contains("description cannot be null and must be no more than 50 characters"));
    }

    @Test
    void testGetName() {
        Task task = new Task(validId, validName, validDescription);
        assertEquals(validName, task.getName());
    }

    @Test
    void testGetDescription() {
        Task task = new Task(validId, validName, validDescription);
        assertEquals(validDescription, task.getDescription());
    }
}
