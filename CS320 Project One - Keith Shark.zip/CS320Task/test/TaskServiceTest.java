import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService taskService;
    private String validId;
    private String validName;
    private String validDescription;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
        validId = "T123456789";
        validName = "Test Task";
        validDescription = "This is a test task description";
    }

    @Test
    void testAddTask() {
        taskService.addTask(validId, validName, validDescription);
        assertEquals(1, taskService.tasks.size());
        assertEquals(validId, taskService.tasks.get(0).ID);
        assertEquals(validName, taskService.tasks.get(0).getName());
        assertEquals(validDescription, taskService.tasks.get(0).getDescription());
    }

    @Test
    void testAddTaskWithDuplicateId() {
        taskService.addTask(validId, validName, validDescription);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(validId, "Different Name", "Different Description");
        });
        assertTrue(exception.getMessage().contains("A task with that ID already exists"));
    }

    @Test
    void testDeleteTaskExistingTask() {
        taskService.addTask(validId, validName, validDescription);
        assertEquals(1, taskService.tasks.size());

        taskService.deleteTask(validId);

        assertEquals(0, taskService.tasks.size());
    }

    @Test
    void testUpdateFieldsExistingTask() {
        taskService.addTask(validId, validName, validDescription);

        String newName = "Updated Task Name";
        String newDescription = "Updated task description";

        taskService.updateFields(validId, newName, newDescription);

        Task updatedTask = taskService.tasks.get(0);
        assertEquals(validId, updatedTask.ID);
        assertEquals(newName, updatedTask.getName());
        assertEquals(newDescription, updatedTask.getDescription());
    }

    @Test
    void testUpdateFieldsOnlyName() {
        taskService.addTask(validId, validName, validDescription);

        String newName = "Updated Task Name";
        String emptyDescription = "";

        taskService.updateFields(validId, newName, emptyDescription);

        Task updatedTask = taskService.tasks.get(0);
        assertEquals(validId, updatedTask.ID);
        assertEquals(newName, updatedTask.getName());
        assertEquals(validDescription, updatedTask.getDescription());
    }

    @Test
    void testUpdateFieldsOnlyDescription() {
        taskService.addTask(validId, validName, validDescription);

        String emptyName = "";
        String newDescription = "Updated task description";

        taskService.updateFields(validId, emptyName, newDescription);

        Task updatedTask = taskService.tasks.get(0);
        assertEquals(validId, updatedTask.ID);
        assertEquals(validName, updatedTask.getName());
        assertEquals(newDescription, updatedTask.getDescription());
    }

    @Test
    void testDeleteTaskWithNullId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask(null);
        });
        assertEquals("id cannot be null", exception.getMessage());
    }

    @Test
    void testUpdateFieldsWithNullId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateFields(null, "New Name", "New Description");
        });
        assertEquals("id cannot be null", exception.getMessage());
    }
}
