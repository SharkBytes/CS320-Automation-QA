import java.util.ArrayList;

public class TaskService {

    ArrayList<Task> tasks;

    TaskService() {
        tasks = new ArrayList<Task>();
    }


    void addTask(String id, String name, String description) {
        // check if there's a duplicate task
        for (Task task : tasks) {
            if (task.ID.equals(id))
                throw new IllegalArgumentException("A task with that ID already exists.");
        }
        tasks.add(new Task(id, name, description));
    }

    void deleteTask(String id) {
        if (id == null)
            throw new IllegalArgumentException("id cannot be null");
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).ID.equals(id)) {
                tasks.remove(i);
                return;
            }
        }
        System.out.println(String.format("Task with id(%s) does not exist.", id));
    }

    void updateFields(String id, String name, String desc) {
        if(id == null)
            throw new IllegalArgumentException("id cannot be null");
        for (Task task : tasks) {
            if (task.ID.equals(id)) {
                if (!name.isEmpty())
                    task.setName(name);
                if (!desc.isEmpty())
                    task.setDescription(desc);
                return;
            }
        }

        System.out.println(String.format("Task with id(%s) does not exist.", id));
    }

}
