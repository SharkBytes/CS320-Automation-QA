
public class Task {

    final String ID;
    private String name;
    private String description;

    Task(String id, String name, String description) {
        if (id == null || id.length() > 10)
            throw new IllegalArgumentException("id cannot be null and must be no more than 10 characters!");
        this.ID = id;
        this.setName(name);
        this.setDescription(description);
    }

    public void setName(String newName) {
        if (newName == null || newName.length() > 20)
            throw new IllegalArgumentException("name cannot be null and must be no more than 20 characters!");
        this.name = newName;
    }

    public void setDescription(String newDescription) {
        if (newDescription == null || newDescription.length() > 50)
            throw new IllegalArgumentException("description cannot be null and must be no more than 50 characters!");
        this.description = newDescription;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

}
