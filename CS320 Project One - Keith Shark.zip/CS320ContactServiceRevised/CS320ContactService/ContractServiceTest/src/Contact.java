public class Contact {

    final private String Id;
    private String firstName;
    private String lastName;
    private String number;
    private String address;

    Contact(String id, String firstName, String lastName, String number, String address) {

        // safe guards
        if (id == null || lastName == null || firstName == null || number == null || address == null)
            throw new IllegalArgumentException("id, first name, last name, number, address cannot be null");
        if (id.length() > 10 || lastName.length() > 10 || firstName.length() > 10 || number.length() > 10 || address.length() > 30)
            throw new IllegalArgumentException("id, first name, last name, number, address cannot be longer than 10 characters");
        
        this.Id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.number = number;
    }

    public String getId() {
        return Id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getNumber() {
        return number;
    }

    public String getAddress() {
        return address;
    }

    public void setFirstName( String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
