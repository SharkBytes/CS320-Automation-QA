import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.Before;
import org.junit.Test;

public class ContactServiceTest {

    private ContactService contactService;

    @Before
    public void setUp() {
        // Create a new ContactService instance before each test
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        // Create a contact with valid data
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Test St");

        
        assertDoesNotThrow(()->{
            // Add the contact to the service
            contactService.addContact(contact);
        });
    }
    @Test
    public void addContactDuplicate(){

        // Create a contact with valid data
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Test St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, ()->{
            contactService.addContact(contact);
        });

    }

    @Test
    public void testRemoveContact() {
        // Create and add a contact
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Test St");
        contactService.addContact(contact);

        // Remove the contact
        contactService.removeContact(contact.getId());

        // We assume the contact was removed successfully if no exceptions were thrown
        assertTrue(true);
    }

    @Test
    public void testRemoveNonExistentContact() {
        // Try to remove a contact that doesn't exist (should not throw exception)
        contactService.removeContact("nonexistent");

        // If we got here without exception, the test passes
        assertTrue(true);
    }

    @Test
    public void testEditContact() {
        // Create and add a contact
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Test St");
        contactService.addContact(contact);

        // Edit the contact
        String newFirstName = "Jane";
        String newLastName = "Smith";
        String newNumber = "0987654321";
        String newAddress = "456 Main Ave";

        contactService.editContact(contact.getId(), newFirstName, newLastName, newNumber, newAddress);

        // Without helper methods, we can't directly verify the values changed
        // We assume the edit succeeded if no exceptions were thrown
        assertTrue(true);
    }

    @Test
    public void testEditNonExistentContact() {
        // Try to edit a contact that doesn't exist (should not throw exception)
        contactService.editContact("nonexistent", "John", "Doe", "1234567890", "123 Test St");

        // If we got here without exception, the test passes
        assertTrue(true);
    }

    @Test
    public void testAddMultipleContacts() {
        // Create and add multiple contacts
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Test St");
        Contact contact2 = new Contact("67890", "Jane", "Smith", "0987654321", "456 Main Ave");

        contactService.addContact(contact1);
        contactService.addContact(contact2);

        // We assume both contacts were added successfully if no exceptions were thrown
        assertTrue(true);
    }

    @Test
    public void testAddContactWithUniqueId() {
        // Create contacts with placeholder unique IDs
        String uniqueId1 = "12345678";
        String uniqueId2 = "87654321";

        Contact contact1 = new Contact(uniqueId1, "John", "Doe", "1234567890", "123 Test St");
        Contact contact2 = new Contact(uniqueId2, "Jane", "Smith", "0987654321", "456 Main Ave");

        contactService.addContact(contact1);
        contactService.addContact(contact2);

        // We assume both contacts were added successfully if no exceptions were thrown
        assertTrue(true);
    }
}
