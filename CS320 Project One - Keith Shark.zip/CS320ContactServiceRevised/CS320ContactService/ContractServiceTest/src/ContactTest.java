import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ContactTest {

    @Test
    public void createClass() {
        Contact user = new Contact("123456", "John", "Smith", "154851", "204 Bob street");
        assertTrue(user.getId().equals("123456"));
        assertTrue(user.getFirstName().equals("John"));
        assertTrue(user.getLastName().equals("Smith"));
        assertTrue(user.getNumber().equals("154851"));
        assertTrue(user.getAddress().equals("204 Bob street"));
    }

    @Test
    public void NullChecker() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Smith", "12475", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", null, "Smith", "12475", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "John", null, "12475", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "John", "Smith", null, "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "John", "Smith", "12475", null);
        });
    }

    @Test
    public void LengthChecker() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("125555555555", "John", "Smith", "12475", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "Johnnnnnnnn", "Smith", "12475", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "John", "Smithhhhhhh", "12475", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "John", "Smith", "1548548615285", "420 Robber Street");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12", "John", "Smith", "12475", "Insert someones address here....");
        });
    }

}
