import java.util.ArrayList;

public class ContactService {

    private ArrayList<Contact> contacts;

    ContactService() {
        contacts = new ArrayList<>();
    }

    void addContact(Contact contact) {
        for (Contact c : this.contacts){
            if(c.getId().equals(contact.getId()))
                throw new IllegalArgumentException("Duplicate id found...");
        }
        contacts.add(contact);
    }

    void removeContact(String id) {
        contacts.removeIf(contact -> contact.getId().equals(id));
    }

    void editContact(String id, String firstName, String lastName, String Number, String Address) {
        for (Contact contact : contacts) {
            if (contact.getId().equals(id)) {
                contact.setFirstName(firstName);
                contact.setLastName(lastName);
                contact.setNumber(Number);
                contact.setAddress(Address);
            }
        }
    }

}
